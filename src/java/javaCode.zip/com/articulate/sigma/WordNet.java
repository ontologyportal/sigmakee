/* This code is copyrighted by Teknowledge (c) 2003.
It is released underthe GNU Public License <http://www.gnu.org/copyleft/gpl.html>.
Users ofthis code also consent, by use of this code, to credit Teknowledge in any
writings, briefings,publications, presentations, or other representations of any
software which incorporates, builds on, or uses this code.*/

package com.articulate.sigma;

import java.io.*;
import java.util.*;
import java.util.regex.*;

/******************************************************************
*  This program finds and displays SUMO terms that are related in meaning to the English
*  expressions that are entered as input.  Note that this program uses four WordNet data
*  files, "NOUN.IDX" and "NOUN.EXC", "VERB.IDX" and "VERB.EXC", as well as two WordNet two SUMO
*  mappings files called "MergeMappings.txt" and "WordNetMappings-verbs.txt"
*  The main part of the program prompts the user for an English term and then
*  returns associated SUMO concepts.  There are two public methods: initOnce() and page().
*  @author Ian Niles
*  @author Adam Pease
*/

public class WordNet {

    public static WordNet wn;
    public static boolean initNeeded = true;
    private Hashtable nounSynsetHash = new Hashtable();
    private Hashtable verbSynsetHash = new Hashtable();
    private Hashtable verbDocumentationHash = new Hashtable();
    private Hashtable nounDocumentationHash = new Hashtable();
    private Hashtable nounSUMOHash = new Hashtable();
    private Hashtable verbSUMOHash = new Hashtable();
    private Hashtable exceptionNounHash = new Hashtable();
    private Hashtable exceptionVerbHash = new Hashtable();
    private String mixedCase;
    private String input;
  
    private Pattern p;
    private Matcher m;

    /******************************************************************
    *  Create the hashtables nounSynsetHash, nounDocumentationHash,
    *  nounSUMOhash and exceptionNounHash that contain the WordNet
    *  noun synsets, word definitions, mappings to SUMO, and plural
    *  exception forms, respectively.
    *  Throws an IOException if the files are not found.
    */
    private void readNouns () throws java.io.IOException {

        FileReader r = new FileReader(KBmanager.getMgr().getPref("kbDir") + File.separator + "NOUN.IDX");
        LineNumberReader lr = new LineNumberReader(r);
        String line;
        while ((line = lr.readLine()) != null) {
            p = Pattern.compile("^(\\S+)\\sn\\s[\\S\\s]+?([0-9]{8}[\\S\\s]*)");
            m = p.matcher(line);
            if (m.matches())
                nounSynsetHash.put(m.group(1),m.group(2));
        }

        r = new FileReader(KBmanager.getMgr().getPref("kbDir") + File.separator + "MergeMappings.txt");
        lr = new LineNumberReader(r);
        while ((line = lr.readLine()) != null) {
            p = Pattern.compile("^([0-9]{8})[\\S\\s]+\\|\\s([\\S\\s]+?)\\s(\\(?\\&\\%\\S+[\\S\\s]+)$");
            m = p.matcher(line);
            if (m.matches()) {
                nounDocumentationHash.put(m.group(1),m.group(2));
                nounSUMOHash.put(m.group(1),m.group(3));
            }
            else {
                p = Pattern.compile("^([0-9]{8})[\\S\\s]+\\|\\s([\\S\\s]+)$");
                m = p.matcher(line);
                if (m.matches())
                {
                  nounDocumentationHash.put(m.group(1),m.group(2));
                }
            }
        }
    
        r = new FileReader(KBmanager.getMgr().getPref("kbDir") + File.separator + "NOUN.EXC");
        lr = new LineNumberReader(r);
        while ((line = lr.readLine()) != null) {
            p = Pattern.compile("(\\S+)\\s+(\\S+)");
            m = p.matcher(line);
            if (m.matches()) {
                exceptionNounHash.put(m.group(1),m.group(2));
            }
        }
    }

  /******************************************************************
  *  Create the hashtables verbSynsetHash, verbDocumentationHash,
  *  verbSUMOhash and exceptionVerbHash that contain the WordNet
  *  verb synsets, word definitions, mappings to SUMO, and plural
  *  exception forms, respectively.
  *  Throws an IOException if the files are not found.
  */

  private void readVerbs () {

    try {
        FileReader r = new FileReader(KBmanager.getMgr().getPref("kbDir") + File.separator + "VERB.IDX");
        LineNumberReader lr = new LineNumberReader(r);
        String line;
        while ((line = lr.readLine()) != null) {
            p = Pattern.compile("^(\\S+)\\sv\\s[\\S\\s]+?([0-9]{8}[\\S\\s]*)");
            m = p.matcher(line);
            if (m.matches())
                verbSynsetHash.put(m.group(1),m.group(2));
        }
    }
    catch (IOException i) { System.err.println("error reading file VERB.IDX <P>\n"); }
    try {
        FileReader r = new FileReader(KBmanager.getMgr().getPref("kbDir") + File.separator + "WordNetMappings-verbs.txt");
        LineNumberReader lr = new LineNumberReader(r);
        String line;
        while ((line = lr.readLine()) != null) {
            p = Pattern.compile("^([0-9]{8})[\\S\\s]+\\|\\s([\\S\\s]+?)\\s(\\(?\\&\\%\\S+[\\S\\s]+)$");
            m = p.matcher(line);
            if (m.matches()) {
                verbDocumentationHash.put(m.group(1),m.group(2));
                verbSUMOHash.put(m.group(1),m.group(3));
            }
            else {
                p = Pattern.compile("^([0-9]{8})[\\S\\s]+\\|\\s([\\S\\s]+)$");
                m = p.matcher(line);
                if (m.matches()) {
                    verbDocumentationHash.put(m.group(1),m.group(2));
                }
            }
        }
    }
    catch (IOException i) {System.err.println("error reading file WordNetMappings-verbs.txt <P>\n");}

    try {
        FileReader r = new FileReader(KBmanager.getMgr().getPref("kbDir") + File.separator + "VERB.EXC");
        LineNumberReader lr = new LineNumberReader(r);
        String line;
        while ((line = lr.readLine()) != null) {
            p = Pattern.compile("(\\S+)\\s+(\\S+)");
            m = p.matcher(line);
            if (m.matches()) {
                exceptionVerbHash.put(m.group(1),m.group(2));
            }
        }
    }
    catch (IOException i) {System.err.println("error reading file VERB.EXC <P>\n");}
  }

  /******************************************************************
  *  Read the WordNet files only on initialization of the class.
  */

  public static void initOnce() throws java.io.IOException {
   
      if (initNeeded == true) {
          wn = new WordNet();
          wn.readNouns();
          wn.readVerbs();
          initNeeded = false;
      }
  }

  /******************************************************************
  *  A utility function that mimics the functionality of the perl
  *  substitution feature (s/match/replacement/).  Note that only
  *  one replacement is made, not a global replacement.
  *  @param result is the string on which the substitution is performed.
  *  @param match is the substring to be found and replaced.
  *  @param subst is the string replacement for match.
  *  @return is a String containing the result of the substitution.
  */
  private String subst (String result, String match, String subst) {

    Pattern p = Pattern.compile(match);
    Matcher m = p.matcher(result);
    if (m.find()) {
        result = m.replaceFirst(subst);
    }
    return result;
  }

  /******************************************************************
  *  A utility function that mimics the functionality of the perl
  *  substitution feature (s/match/replacement/) but rather thanf
  *  returning the result of the substitution, just tests whether the
  *  result is a key in a hashtable.  Note that only
  *  one replacement is made, not a global replacement.
  *  @param result is the string on which the substitution is performed.
  *  @param match is the substring to be found and replaced.
  *  @param subst is the string replacement for match.
  *  @param hash is a hashtable to be checked against the result.
  *  @return is a boolean indicating whether the result of the substitution
  *  was found in the hashtable.
  */
  private boolean substTest (String result, String match, String subst, Hashtable hash) {

      Pattern p = Pattern.compile(match);
      Matcher m = p.matcher(result);
      if (m.find()) {
          result = m.replaceFirst(subst);
          if (hash.containsKey(result)) {
              return true;
          }
          return false;
      }
      else
          return false;
  }

  /******************************************************************
  *  The main routine which looks up the search word in the hashtables
  *  to find the relevant word definitions and SUMO mappings.
  *  @param word is the word the user is asking to search for.
  *  @param type is whether the word is a noun or verb (we need to add capability for adjectives and adverbs.
  *  @param
  */

  private String sumoDisplay(String synsetBlock, String word, String type, String sumokbname) {

      StringBuffer result = new StringBuffer();

  // Split apart the block of synsets, and store the separated values as an array.

      String synset;
      String documentation = new String();
      String sumoEquivalent = new String();
      int listLength;
      String[] synsetList = synsetList = synsetBlock.split("\\s+");

      if (synsetList != null)
          listLength = synsetList.length;
      else
          listLength = 0;
      int count = 1;
      result.append("<h4>According to WordNet, the " + type + "\"" + word + "\" has ");
      result.append(String.valueOf(listLength) + " sense(s).\n\n</h4>");

  // Split apart the SUMO concepts, and store them as an associative array.

      for (int i=0; i<listLength; i++) {
          synset = synsetList[i];
          synset.trim();
          if (type.compareTo("noun") == 0) {
              documentation = (String) nounDocumentationHash.get(synset);
              result.append(String.valueOf(count) + ". " + documentation + ".\n");
              sumoEquivalent = (String) nounSUMOHash.get(synset);
          }
          else {
              if (type.compareTo("verb") == 0) {
                  documentation = (String) verbDocumentationHash.get(synset);
                  result.append(String.valueOf(count) + ". " + documentation + ".\n");
                  sumoEquivalent = (String) verbSUMOHash.get(synset);
              }
          }
          String[] sumoList = sumoEquivalent.split("\\s+");
          if (sumoList.length == 0) {
              result.append("<P><ul><li>Not yet mapped to SUMO");
          } else {

              result.append("<P><ul><li>\tSUMO Equivalents:  ");
              for (int j=0; j<sumoList.length; j++) {
                  sumoEquivalent = sumoList[j];
                  sumoEquivalent.trim();

                  Pattern p = Pattern.compile("\\&\\%");
                  Matcher m = p.matcher(sumoEquivalent);
                  sumoEquivalent = m.replaceFirst("");
                  p = Pattern.compile("[\\=\\|\\+\\@]");
                  m = p.matcher(sumoEquivalent);
                  sumoEquivalent = m.replaceFirst("");
                  result.append("<a href=\"Browse.jsp?term=");
                  result.append(sumoEquivalent + "&kb=" + sumokbname + "\">" + sumoEquivalent + "</a>  ");
             }
        }
        result.append("\n\n</li></ul>");
        count = count + 1;
    }
    result.append("<hr>Explore the word <a href=\"http://www.cogsci.princeton.edu/cgi-bin/webwn/?stage=1&word=");
    result.append(word + "\">"+ word + "</a> on the WordNet web site.\n");
    return result.toString();
  }

  /******************************************************************
  *  This routine converts a noun to its singular form and gets the synsets for it,
  *  then passes those synsets to sumoDisplay() for processing.
  *  First check to see if the input value or its lower-case version are entered in the
  *  WordNet exception list (NOUN.EXC).  If so, then use the regular form in the exception
  *  list to find the synsets in the NOUN.DAT file.
  *  If the word is not in the exception list, check to see if the lower case version of
  *  the input value is a plural and search over NOUN.DAT in the singular form if it is.
  */
  private String processNoun (String sumokbname) {

      StringBuffer result = new StringBuffer();
      String regular = new String();
      String synsetBlock;

      if ((exceptionNounHash.containsKey(mixedCase)) ||
           (exceptionNounHash.containsKey(input))) {
          if (exceptionNounHash.containsKey(mixedCase))
              regular = (String) exceptionNounHash.get(mixedCase);
          else
              regular = (String) exceptionNounHash.get(input);
          synsetBlock = (String) nounSynsetHash.get(regular);
          result.append(sumoDisplay(synsetBlock, mixedCase, "noun", sumokbname));
      }

      else {
        // Test all regular plural forms, and correct to singular.
          if (substTest(input,"s$","",nounSynsetHash)) {
              input = subst(input,"s$","");
              synsetBlock = (String) nounSynsetHash.get(input);
              result.append(sumoDisplay(synsetBlock, mixedCase, "noun", sumokbname));
          }
          else {
              if (substTest(input,"ses$","s", nounSynsetHash)) {
                  input = subst(input,"ses$","s");
                  synsetBlock = (String) nounSynsetHash.get(input);
                  result.append(sumoDisplay(synsetBlock, mixedCase, "noun", sumokbname));
              }
              else {
                  if (substTest(input,"xes$","x", nounSynsetHash)) {
                      input = subst(input,"xes$","x");
                      synsetBlock = (String) nounSynsetHash.get(input);
                      result.append(sumoDisplay(synsetBlock, mixedCase, "noun", sumokbname));
                  }
                  else {
                      if (substTest(input,"zes$","z", nounSynsetHash)) {
                          input = subst(input,"zes$","z");
                          synsetBlock = (String) nounSynsetHash.get(input);
                          result.append(sumoDisplay(synsetBlock, mixedCase, "noun", sumokbname));
                      }
                      else {
                          if (substTest(input,"ches$","ch", nounSynsetHash)) {
                              input = subst(input,"ches$","ch");
                              synsetBlock = (String) nounSynsetHash.get(input);
                              result.append(sumoDisplay(synsetBlock, mixedCase, "noun", sumokbname));
                          }
                          else {
                              if (substTest(input,"shes$","sh", nounSynsetHash)) {
                                  input = subst(input,"shes$","sh");
                                  synsetBlock = (String) nounSynsetHash.get(input);
                                  result.append(sumoDisplay(synsetBlock, mixedCase, "noun", sumokbname));
                              }
                              else {
                                  if (nounSynsetHash.containsKey(mixedCase)) {
                                      synsetBlock = (String) nounSynsetHash.get(mixedCase);
                                      result.append(sumoDisplay(synsetBlock, mixedCase, "noun", sumokbname));
                                  }
                                  else {
                                      if (nounSynsetHash.containsKey(input)) {
                                          synsetBlock = (String) nounSynsetHash.get(input);
                                          result.append(sumoDisplay(synsetBlock, mixedCase, "noun", sumokbname));
                                      }
                                      else
                                          result.append("<P>There are no associated SUMO terms for the noun \"" + mixedCase + "\".<P>\n");
                                  }
                              }
                          }
                      }
                  }
              }
          }
      }
      return (result.toString());
  }

  /******************************************************************
  *  This routine converts a verb to its present tense singular form and gets the synsets for it,
  *  then passes those synsets to sumoDisplay() for processing.
  *  First check to see if the input value or its lower-case version are entered in the
  *  WordNet exception list (VERB.EXC).  If so, then use the regular form in the exception
  *  list to find the synsets in the VERB.DAT file.
  *  If the word is not in the exception list, check to see if the lower case version of the
  *  input value is a singular form and search over VERB.DAT with the infinitive form if it is.
  */
  private String processVerb(String sumokbname) {

      StringBuffer result = new StringBuffer();
      String regular = new String();
      String synsetBlock;

      if ((exceptionVerbHash.containsKey(mixedCase)) ||
           (exceptionVerbHash.containsKey(input))) {
          if (exceptionVerbHash.containsKey(mixedCase))
              regular = (String) exceptionVerbHash.get(mixedCase);
          else
              regular = (String) exceptionVerbHash.get(input);
          synsetBlock = (String) verbSynsetHash.get(regular);
          result.append(sumoDisplay(synsetBlock, mixedCase, "verb", sumokbname));
      }

      else {
        // Test all regular forms and convert to present tense singular.
          if (substTest(input,"s$","",verbSynsetHash)) {
              input = subst(input,"s$","");
              synsetBlock = (String) verbSynsetHash.get(input);
              result.append(sumoDisplay(synsetBlock, mixedCase, "verb", sumokbname));
          }
          else {
              if (substTest(input,"es$","",verbSynsetHash)) {
                  input = subst(input,"es$","");
                  synsetBlock = (String) verbSynsetHash.get(input);
                  result.append(sumoDisplay(synsetBlock, mixedCase, "verb", sumokbname));
              }
              else {
                  if (substTest(input,"ies$","y",verbSynsetHash)) {
                      input = subst(input,"ies$","y");
                      synsetBlock = (String) verbSynsetHash.get(input);
                      result.append(sumoDisplay(synsetBlock, mixedCase, "verb", sumokbname));
                  }
                  else {
                      if (substTest(input,"ed$","",verbSynsetHash)) {
                          input = subst(input,"ed$","");
                          synsetBlock = (String) verbSynsetHash.get(input);
                          result.append(sumoDisplay(synsetBlock, mixedCase, "verb", sumokbname));
                      }
                      else {
                          if (substTest(input,"ed$","e",verbSynsetHash)) {
                              input = subst(input,"ed$","e");
                              synsetBlock = (String) verbSynsetHash.get(input);
                              result.append(sumoDisplay(synsetBlock, mixedCase, "verb", sumokbname));
                          }
                          else {
                              if (substTest(input,"ing$","e",verbSynsetHash)) {
                                  input = subst(input,"ing$","e");
                                  synsetBlock = (String) verbSynsetHash.get(input);
                                  result.append(sumoDisplay(synsetBlock, mixedCase, "verb", sumokbname));
                               }
                               else {
                                   if (substTest(input,"ing$","",verbSynsetHash)) {
                                       input = subst(input,"ing$","");
                                       synsetBlock = (String) verbSynsetHash.get(input);
                                       result.append(sumoDisplay(synsetBlock, mixedCase, "verb", sumokbname));
                                    }
                                    else {
                                       if (verbSynsetHash.containsKey(mixedCase)) {
                                           synsetBlock = (String) verbSynsetHash.get(mixedCase);
                                           result.append(sumoDisplay(synsetBlock, mixedCase, "verb", sumokbname));
                                       }
                                       else {
                                           if (verbSynsetHash.containsKey(input)) {
                                               synsetBlock = (String) verbSynsetHash.get(input);
                                               result.append(sumoDisplay(synsetBlock, mixedCase, "verb", sumokbname));
                                            }
                                            else
                                                result.append("<P>There are no associated SUMO terms for the verb \"" + mixedCase + "\".<P>\n");
                                          }
                             }
                                  }
                             }
                          }
                 }
              }
          }
      }
      return (result.toString());
  }

  /******************************************************************
  *  This is the regular point of entry for this class.  It takes the
  *  word the user is searching for, and the part of speech index,
  *  does the search, and returns the string with HTML formatting codes
  *  to present to the user.
  *  @param inp The string the user is searching for.
  *  @param pos The part of speech of the word 1=noun, 2=verb.
  *  @return A string contained the HTML formatted search result.
  */
  public String page (String inp, int pos, String sumokbname) {
    
    input = inp;
    StringBuffer buf = new StringBuffer();

    mixedCase = input;
    String[] s = input.split("\\s+");
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < s.length; i++) {
        sb.append(s[i]);
        if ((i+1)<s.length) {
            sb.append("_");
        }
    }

    input = sb.toString().toLowerCase();
    System.out.println("INFO in WordNet.page(): " + input);
    if (pos==1)
        buf.append(processNoun(sumokbname));
    if (pos==2)
        buf.append(processVerb(sumokbname));
    buf.append("\n");

    return buf.toString();
  }

  /******************************************************************
  *  A main method, used only for testing.  It should not be called
  *  during normal operation.
  */

  public static void main (String[] args)
  {
    String termName = "English";
    String POS = "noun";
    String sumokbname = "SUMO";
    WordNet.wn.page(termName,Integer.decode(POS).intValue(),sumokbname);
  }

} 
