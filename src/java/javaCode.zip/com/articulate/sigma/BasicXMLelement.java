package com.articulate.sigma;

import java.util.*;
public class BasicXMLelement {

    public String tagname = null;
    public HashMap attributes = new HashMap();
    public ArrayList subelements = new ArrayList();
    public String contents = "";


    /******************************************************************
     * Convert the XML element to a String.
     */
    public String toString() {

        StringBuffer result = new StringBuffer();
        result = result.append("<" + tagname);
        Iterator it = attributes.keySet().iterator();
        while (it.hasNext()) {
            String key = (String) it.next();
            String value = (String) attributes.get(key);
            result = result.append(" " + key + "='" + value + "'");
        }
        result = result.append(">");
        if (contents != null)
            result = result.append(contents);
        for (int i = 0; i < subelements.size(); i++) {
            BasicXMLelement el = (BasicXMLelement) subelements.get(i);
            result = result.append(el.toString());
        }
        result = result.append("</" + tagname + ">\n");
        return result.toString();
    }
}

